package kz.diploma.workgram.views.home

import android.view.View

interface HomeNextViewDelegate {
    fun onNextButtonClicked(view: View);
}