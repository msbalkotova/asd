package kz.diploma.workgram.views.auth

import android.view.View

interface NextViewDelegate {
    fun onNextButtonClicked(view: View);
}