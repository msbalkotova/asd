package kz.diploma.workgram.views.employee

import androidx.lifecycle.ViewModel

class EmployeeViewModel: ViewModel() {
}