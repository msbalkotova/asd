package kz.diploma.workgram.utils.helpers

enum class ErrorCatcher {
    PHONE_REQ,
    EMAIL_REQ,
    SUCCESS,
    PASS_LENGTH
}