package kz.diploma.workgram.views

import androidx.fragment.app.Fragment

open class BaseFragment: Fragment() {
}