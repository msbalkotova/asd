package kz.diploma.workgram.utils

enum class PasswordCheckEnum {
    CORRECT,
    AT_LAST_8,
    SPEC_CHARS,
    HASNT_UPPER,
    HASNT_LOWER,
    NOT_MATH
}