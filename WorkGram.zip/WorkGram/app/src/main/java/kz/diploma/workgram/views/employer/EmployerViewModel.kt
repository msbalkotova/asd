package kz.diploma.workgram.views.employer

import androidx.lifecycle.ViewModel

class EmployerViewModel: ViewModel() {
}