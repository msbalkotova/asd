package kz.diploma.workgram.repositories

class WorkersRepository {
}