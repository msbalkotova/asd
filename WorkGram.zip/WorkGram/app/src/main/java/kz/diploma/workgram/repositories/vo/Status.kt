package kz.diploma.workgram.repositories.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}