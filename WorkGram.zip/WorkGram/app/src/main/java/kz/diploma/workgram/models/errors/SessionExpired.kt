package kz.diploma.workgram.models.errors

data class SessionExpired(
    var isExpired: Boolean = true
)